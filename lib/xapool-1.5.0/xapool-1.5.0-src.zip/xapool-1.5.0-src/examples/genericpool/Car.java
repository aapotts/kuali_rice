


public class Car {
    String brand = null;
    String color = null;

    public Car() {
    }

    public void setBrand(String abrand) {
        this.brand = abrand;
    }

    public void setColor(String acolor) {
        this.color = acolor;
    }

    public String getBrand() {
        return this.brand;
    }

    public String getColor() {
        return this.color;
    }
}
