package com.thoughtworks.acceptance.someobjects;

/**
 *
 * 
 *  <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: Protocol.java,v 1.2 2006/09/25 14:26:13 bnelson Exp $
 */
public class Protocol
{
    private String id;

    public String getId()
    {
        return id;
    }
}
