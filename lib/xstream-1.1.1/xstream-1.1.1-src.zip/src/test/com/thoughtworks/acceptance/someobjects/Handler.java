package com.thoughtworks.acceptance.someobjects;

/**
 *
 * 
 *  <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: Handler.java,v 1.2 2006/09/25 14:26:13 bnelson Exp $
 */
public class Handler
{
    private Protocol protocol;

    public Protocol getProtocol()
    {
        return protocol;
    }
}
