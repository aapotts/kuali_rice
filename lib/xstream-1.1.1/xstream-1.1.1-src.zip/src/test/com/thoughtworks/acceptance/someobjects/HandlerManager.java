package com.thoughtworks.acceptance.someobjects;

import java.util.List;

/**
 *
 * 
 *  <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: HandlerManager.java,v 1.2 2006/09/25 14:26:13 bnelson Exp $
 */
public class HandlerManager
{
    List handlers;

    public List getHandlers()
    {
        return handlers;
    }
}
