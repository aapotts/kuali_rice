Example Signatures[1]

[1] http://www.w3.org/Signature/Drafts/xmldsig-core/Overview.html

See signature-*.xml

The key for the HMAC-SHA1 signatures is "secret".getBytes("ASCII")
which is, in hex, (73 65 63 72 65 74).

Included in the directory are:

  signature-*.xml - The signatures
  signature-*-c14n-?.txt - The intermediate c14n output

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.

Friday, March 23, 2001
