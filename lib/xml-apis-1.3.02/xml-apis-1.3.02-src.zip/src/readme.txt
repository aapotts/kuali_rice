I couldn't find a source distribution, so I got this from:
svn co http://svn.apache.org/repos/asf/xml/commons/tags/xml-commons-external-1_3_02/java/external/