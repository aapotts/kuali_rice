/*
 * Copyright (c) 2002-2006 Gargoyle Software Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The end-user documentation included with the redistribution, if any, must
 *    include the following acknowledgment:
 *
 *       "This product includes software developed by Gargoyle Software Inc.
 *        (http://www.GargoyleSoftware.com/)."
 *
 *    Alternately, this acknowledgment may appear in the software itself, if
 *    and wherever such third-party acknowledgments normally appear.
 * 4. The name "Gargoyle Software" must not be used to endorse or promote
 *    products derived from this software without prior written permission.
 *    For written permission, please contact info@GargoyleSoftware.com.
 * 5. Products derived from this software may not be called "HtmlUnit", nor may
 *    "HtmlUnit" appear in their name, without prior written permission of
 *    Gargoyle Software Inc.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL GARGOYLE
 * SOFTWARE INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.gargoylesoftware.htmlunit.html;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.gargoylesoftware.htmlunit.CollectingAlertHandler;
import com.gargoylesoftware.htmlunit.MockWebConnection;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebTestCase;

/**
 *  Tests for HtmlFrame
 *
 * @version  $Revision: 1129 $
 * @author <a href="mailto:mbowler@GargoyleSoftware.com">Mike Bowler</a>
 */
public class HtmlFrameTest extends WebTestCase {

    /**
     *  Create an instance
     *
     * @param  name Name of the test
     */
    public HtmlFrameTest( final String name ) {
        super( name );
    }

    /**
     * @throws Exception if the test fails
     */
    public void testSrcOfBlankAndEmpty() throws Exception {
        final String firstContent
            = "<html><head><title>first</title></head>"
            + "<frameset cols='20%,80%'>"
            + "    <frame src='' id='frame1'>"
            + "    <frame src='about:blank'  id='frame2'>"
            + "</frameset></html>";
        final HtmlPage page = loadPage(firstContent);

        final HtmlFrame frame1 = (HtmlFrame)page.getHtmlElementById("frame1");
        assertEquals( "frame1", "", ((HtmlPage)frame1.getEnclosedPage()).getTitleText() );

        final HtmlFrame frame2 = (HtmlFrame)page.getHtmlElementById("frame2");
        assertEquals( "frame2", "", ((HtmlPage)frame2.getEnclosedPage()).getTitleText() );
    }

    /**
     * @throws Exception if the test fails
     */
    public void testOnLoadHandler() throws Exception {
        final WebClient webClient = new WebClient();
        final MockWebConnection webConnection =
            new MockWebConnection(webClient);
        final List collectedAlerts = new ArrayList();

        webClient.setAlertHandler(new CollectingAlertHandler(collectedAlerts));

        final String firstContent
            = "<html><head><title>first</title></head>"
            + "<frameset cols='20%,80%'>"
            + "    <frame id='frame1'>"
            + "    <frame onload='alert(this.tagName)' id='frame2'>"
            + "</frameset></html>";
        final List expectedAlerts = Arrays.asList( new String[]{"FRAME"} );

        webConnection.setResponse(URL_FIRST, firstContent);
        webClient.setWebConnection(webConnection);

        final HtmlPage page = (HtmlPage) webClient.getPage(URL_FIRST);
        assertEquals("first", page.getTitleText());

        final HtmlFrame frame1 = (HtmlFrame)page.getHtmlElementById("frame1");
        assertEquals("frame1", "", ((HtmlPage) frame1.getEnclosedPage()).getTitleText());

        final HtmlFrame frame2 = (HtmlFrame)page.getHtmlElementById("frame2");
        assertEquals("frame2", "", ((HtmlPage)frame2.getEnclosedPage()).getTitleText());

        assertEquals(expectedAlerts, collectedAlerts);
    }

    /**
     * @throws Exception if the test fails
     */
    public void testDocumentWrite() throws Exception {
        final String firstContent
            = "<html><head><title>first</title></head>"
            + "<frameset cols='20%,80%'>"
            + "    <frame src='' name='frame1' id='frame1'>"
            + "    <frame onload=\"frame1.document.open();frame1.document.write("
            + "'<html><head><title>generated</title></head><body>generated</body></html>');"
            + "frame1.document.close()\"  id='frame2'>"
            + "</frameset></html>";
        final HtmlPage page = loadPage(firstContent);
        
        assertEquals( "first", page.getTitleText() );

        final HtmlFrame frame1 = (HtmlFrame)page.getHtmlElementById("frame1");
        assertEquals( "frame1", "generated", ((HtmlPage)frame1.getEnclosedPage()).getTitleText() );

        final HtmlFrame frame2 = (HtmlFrame)page.getHtmlElementById("frame2");
        assertEquals( "frame2", "", ((HtmlPage)frame2.getEnclosedPage()).getTitleText() );
    }

    /**
     * Test that frames are correctly deregistered even if not html
     * @throws Exception if the test fails
     */
    public void testDeregisterNonHtmlFrame() throws Exception {
        final WebClient webClient = new WebClient();
        final MockWebConnection webConnection =
            new MockWebConnection(webClient);

        final String firstContent
            = "<html><head><title>first</title></head>"
            + "<frameset cols='100%'>"
            + "    <frame src='foo.txt'>"
            + "</frameset></html>";
        webConnection.setDefaultResponse("foo", 200, "OK", "text/plain");
        webConnection.setResponse(URL_FIRST, firstContent);
        webClient.setWebConnection(webConnection);

        final HtmlPage page = (HtmlPage) webClient.getPage(URL_FIRST);
        assertEquals("first", page.getTitleText());
        
        // loads something else to trigger frame de-registration
        webClient.getPage(URL_SECOND);
    }
}
