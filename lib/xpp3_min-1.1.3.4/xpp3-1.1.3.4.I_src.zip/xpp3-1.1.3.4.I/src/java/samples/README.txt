place for samples demonstrating use of XMLPULL API
